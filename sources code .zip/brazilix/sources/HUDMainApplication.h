//
//  HUDMainApplication.h
//  TrollSpeed
//
//  Created by Lessica on 2024/1/24.
//

#import <UIKit/UIKit.h>

@interface HUDMainApplication : UIApplication
@end